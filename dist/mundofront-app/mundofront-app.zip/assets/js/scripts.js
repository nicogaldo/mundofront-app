function init_plugins() {

 $( document ).ready(function() {
	  console.log( "my scripts" );

	  /*=================================
	  =            Side Menu            =
	  =================================*/
		$('.side-menu').metisMenu({ preventDefault: true });
	  

	});
}